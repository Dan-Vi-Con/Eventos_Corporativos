const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;
const db = require('./db');

const eventoRoutes = require('./routes/eventoRoutes');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());
app.use(express.urlencoded({ extended: true })); 
app.use('/api/eventos', eventoRoutes);
app.get('/', (req, res) => {
    res.redirect('/api/eventos');
});
app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://localhost:${PORT}`);
});