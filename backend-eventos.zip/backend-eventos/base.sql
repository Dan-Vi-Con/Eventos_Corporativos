CREATE DATABASE backend_eventos_db;
USE backend_eventos_db;

CREATE TABLE eventos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_evento VARCHAR(255) NOT NULL,
    fecha_evento DATE NOT NULL,
    ubicacion VARCHAR(255) NOT NULL,
    capacidad_asistentes INT NOT NULL
);

INSERT INTO eventos (nombre_evento, fecha_evento, ubicacion, capacidad_asistentes) 
VALUES 
('Concierto de Power Metal', '2026-07-15', 'Auditorio Nacional', 500),
('Exposición de Arte Pixel', '2026-08-22', 'Galería Digital', 150);