const express = require('express');
const router = express.Router();
const eventoController = require('../controllers/eventoController');

// 1. Ver la lista principal
router.get('/', eventoController.obtenerEventos);

// 2. Mostrar el formulario de creación (GET) y procesarlo (POST)
router.get('/crear', eventoController.mostrarFormularioCrear);
router.post('/crear', eventoController.crearEvento);

// 3. Rutas para Editar
router.get('/editar/:id', eventoController.mostrarFormularioEditar);
router.post('/actualizar', eventoController.actualizarEvento);
// 4. Ruta para eliminar
router.get('/eliminar/:id', eventoController.eliminarEvento);

module.exports = router;