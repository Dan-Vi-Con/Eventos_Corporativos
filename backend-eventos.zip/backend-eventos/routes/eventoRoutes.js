const express = require('express');
const router = express.Router();
const eventoController = require('../controllers/eventoController');
router.get('/', eventoController.obtenerEventos);
router.get('/crear', eventoController.mostrarFormularioCrear);
router.post('/crear', eventoController.crearEvento);
router.get('/editar/:id', eventoController.mostrarFormularioEditar);
router.post('/actualizar', eventoController.actualizarEvento);
router.get('/eliminar/:id', eventoController.eliminarEvento);

module.exports = router;