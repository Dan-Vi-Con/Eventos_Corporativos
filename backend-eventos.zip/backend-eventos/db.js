const mysql = require('mysql2');
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'backend_eventos_db'
});
connection.connect((err) => {
    if (err) {
        console.error('Error', err.message);
        return;
    }
    console.log('!Buena conexion!');
});
module.exports = connection;