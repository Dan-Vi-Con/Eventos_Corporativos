const db = require('../db');

const obtenerEventos = (req, res) => {
    const query = 'SELECT * FROM eventos';
    db.query(query, (err, resultados) => {
        if (err) {
            console.error('Error al obtener eventos:', err);
            return res.status(500).send('Error en la base de datos');
        }
        const eventosFormateados = resultados.map(evento => {
            return {
                ...evento,
                fecha_evento: new Date(evento.fecha_evento).toLocaleDateString('es-ES')
            };
        });
        res.render('index', { eventos: eventosFormateados });
    });
};

const mostrarFormularioCrear = (req, res) => {
    res.render('crear');
};

const crearEvento = (req, res) => {
    const { id, nombre_evento, fecha_evento, ubicacion, capacidad_asistentes } = req.body;
    const query = 'INSERT INTO eventos (id, nombre_evento, fecha_evento, ubicacion, capacidad_asistentes) VALUES (?, ?, ?, ?, ?)';
    
    db.query(query, [id, nombre_evento, fecha_evento, ubicacion, capacidad_asistentes], (err, resultado) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).send(`
                    <div style="font-family: sans-serif; margin: 40px; padding: 20px; background-color: #1a1a2e; color: #e2e2e2; border: 1px solid #3f3f5f; border-radius: 4px; max-width: 500px; margin: 0 auto;">
                        <h2 style="color: #ff6b6b;">Error de Validación</h2>
                        <p>El <strong>ID ${id}</strong> ya está registrado para otro evento.</p>
                        <hr style="border-top: 1px solid #3f3f5f;">
                        <a href="/api/eventos/crear" style="display: inline-block; padding: 10px 15px; background-color: #0f3460; color: white; text-decoration: none; border-radius: 4px; margin-top: 10px;">Volver a intentar</a>
                    </div>
                `);
            }
            console.error('Error al insertar evento:', err);
            return res.status(500).send('Error al guardar el evento');
        }
        res.redirect('/api/eventos');
    });
};

const eliminarEvento = (req, res) => {
    const idEliminar = req.params.id;
    const query = 'DELETE FROM eventos WHERE id = ?';

    db.query(query, [idEliminar], (err, resultado) => {
        if (err) {
            console.error('Error al eliminar el evento:', err);
            return res.status(500).send('Error al intentar eliminar el evento');
        }
        res.redirect('/api/eventos');
    });
};

const mostrarFormularioEditar = (req, res) => {
    const idEditar = req.params.id;
    const query = 'SELECT * FROM eventos WHERE id = ?';

    db.query(query, [idEditar], (err, resultado) => {
        if (err) {
            console.error('Error al buscar el evento:', err);
            return res.status(500).send('Error al buscar el evento');
        }
        if (resultado.length === 0) {
            return res.status(404).send('Evento no encontrado');
        }

        const evento = resultado[0];
        const fecha = new Date(evento.fecha_evento);
        const el_fecha_limpia = fecha.toISOString().split('T')[0];

        res.render('editar', { evento: evento, el_fecha_limpia: el_fecha_limpia });
    });
};

const actualizarEvento = (req, res) => {
    const { id_original, id, nombre_evento, fecha_evento, ubicacion, capacidad_asistentes } = req.body;
    const query = 'UPDATE eventos SET id = ?, nombre_evento = ?, fecha_evento = ?, ubicacion = ?, capacidad_asistentes = ? WHERE id = ?';

    db.query(query, [id, nombre_evento, fecha_evento, ubicacion, capacidad_asistentes, id_original], (err, resultado) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).send(`
                    <div style="font-family: sans-serif; margin: 40px; padding: 20px; background-color: #1a1a2e; color: #e2e2e2; border: 1px solid #3f3f5f; border-radius: 4px; max-width: 500px; margin: 0 auto;">
                        <h2 style="color: #ff6b6b;">Error de Validación</h2>
                        <p>No se pueden guardar los cambios porque el <strong>ID ${id}</strong> ya está siendo utilizado por otro evento.</p>
                        <hr style="border-top: 1px solid #3f3f5f;">
                        <a href="/api/eventos/editar/${id_original}" style="display: inline-block; padding: 10px 15px; background-color: #0f3460; color: white; text-decoration: none; border-radius: 4px; margin-top: 10px;">Volver a intentar</a>
                    </div>
                `);
            }
            console.error('Error al actualizar el evento:', err);
            return res.status(500).send('Error interno al actualizar el evento');
        }
        return res.redirect('/api/eventos');
    });
};

module.exports = {
    obtenerEventos,
    mostrarFormularioCrear,
    crearEvento,
    eliminarEvento,
    mostrarFormularioEditar,
    actualizarEvento
};